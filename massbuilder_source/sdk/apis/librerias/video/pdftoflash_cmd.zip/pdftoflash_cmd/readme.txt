C:\>pdftoflash.exe
PDF to Flash Converter v2.0
Web: http://www.verydoc.com
Web: http://www.verypdf.com
Email: support@verypdf.com
Build: Oct 29 2009
-------------------------------------------------------
Description:
Convert Acrobat PDF files to Flash SWF files.
-------------------------------------------------------
Usage: pdftoflash.exe [options] <PDF Files>
  -firstpage <int>         : first page to print, from 1 to max page
  -lastpage <int>          : last page to print, from 1 to max page
  -pagerange <string>      : set page range, e.g., 2,100-200,250-300
  -swfopt <string>         : set SWF options
    -z : Use Flash 6 (MX) zlib compression
         e.g. : -swfopt "-z"
    -p <range>: Convert only pages in range with range
         e.g. 1-20 or 1,4,6,9-11 or 3-5,10-12
    -i : Allows PDF to Flash to change the draw order of the PDF. This may make
         the generated SWF files a little bit smaller
    -j <quality>: Set quality of embedded jpeg pictures to quality. 0 is worst
         (small), 100 is best (big). (default:85)
         e.g. : -swfopt "-j 50"
    -S : Don't use SWF Fonts, but store everything as shape
    -f : Store all fonts into SWF
    -t : Insert a 'stop' command after each page. The resulting SWF file will
         not turn pages automatically.
    -s zoom=factor : Set resolution to SWF file, default: 72DPI
  -as3                     : creates AS3/AVM2 compatible SWF files
  -swfver <int>            : set Flash version output SWF files
  -swfrate <int>           : set Flash framerate
  -swfburst                : burst PDF file to single page SWF files
  -swfburst2               : burst PDF file to single page SWF files, optimized for speed
  -swfflatten              : flatten complicated graphics in converted SWF file
  -swfmaxopt               : compress and optimize SWF files automatically
  -swfimagequality <int>   : set quality of images in SWF files, 0 is worst (small), 100 is best (big), default is 85
  -swfimagezoom <int>      : resolution adjustment for images in SWF files,
    0: same as original PDF file
    1: adjust resolution to 1x, quality is worst and file is small
    2: adjust resolution to 2x, quality is better than 1
    4: adjust resolution to 4x, quality is better than 2
  -enablepv2r              : enable merge vector graphics into background
  -pv2rxres <int>          : set Y resolution for background,
                             default is 150 DPI
  -pv2ryres <int>          : set Y resolution for background,
                             default is 150 DPI
  -pv2rmergetext <int>     : merge text into background picture
  -pv2ropw <string>        : owner password (for encrypted files)
  -pv2rupw <string>        : user password (for encrypted files)
  -pv2rvaa <string>        : enable or disable vector anti-aliasing, yes/no,
                             default is 'yes'
  -pv2riaa <string>        : enable or disable image anti-aliasing, yes/no,
                             default is 'no'
  -pv2rquality <int>       : set quality for JPEG image, default is 95
  -pv2rshowalltext         : show covered/hidden text on PDF page
  -pv2rdelgfx              : delete all invisible graphics
  -pv2rnolinks             : disable hyperlinks during conversion
  -transparent             : create transparent SWFs
  -mapfont                 : map fonts by mapfont.ini file
  -$ <string>              : input your registration key
Example:
   pdftoflash.exe C:\in.pdf C:\out.swf
   pdftoflash.exe -swfburst C:\in.pdf C:\out.swf
   pdftoflash.exe -swfopt "-z" C:\in.pdf C:\out.swf
   pdftoflash.exe -swfopt "-j 75" C:\in.pdf C:\out.swf
   pdftoflash.exe -swfopt "-p 2 -j 75" C:\in.pdf C:\out.swf
   pdftoflash.exe -swfopt "-p 2,4,6-8 -z -i -j 50 -t" C:\in.pdf C:\out.swf
   pdftoflash.exe -swfopt "-s zoom=150" C:\in.pdf C:\out.swf
   pdftoflash.exe -pagerange "6,7" -swfburst C:\in.pdf C:\out.swf
   pdftoflash.exe -swfburst2 -swfmaxopt -mapfont C:\in.pdf C:\out.swf
   pdftoflash.exe -mapfont -swfburst2 -swfflatten -swfmaxopt -swfimagequality 70 -swfimagezoom 1 C:\in.pdf C:\out.swf
   pdftoflash.exe -enablepv2r C:\in.pdf C:\out.swf
   pdftoflash.exe -enablepv2r -pv2rxres 100 -pv2ryres 100 C:\in.pdf C:\out.swf
   pdftoflash.exe -enablepv2r -pv2rmergetext 0 C:\in.pdf C:\out.swf
   pdftoflash.exe -enablepv2r -pv2rshowalltext 0 C:\in.pdf C:\out.swf
   pdftoflash.exe -transparent C:\in.pdf C:\out.swf
   pdftoflash.exe -mapfont C:\in.pdf C:\out.swf
   pdftoflash.exe -as3 C:\in.pdf C:\out.swf
   for %F in (D:\test\*.pdf) do "pdftoflash.exe" "%F" "%~dpnF.swf"
   for /r D:\test %F in (*.pdf) do "pdftoflash.exe" "%F" "~dpnF.swf"

C:\>